import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.util.Base64;

public class PasswordHasher {
    private static final SecureRandom RAND = new SecureRandom();
    private static final int SALT_LEN = 16;
    private static final int ITERATIONS = 200_000;
    private static final int KEY_LEN = 256;

    public static String hashPassword(String password) throws Exception {
        byte[] salt = new byte[SALT_LEN];
        RAND.nextBytes(salt);
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LEN);
        SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] out = f.generateSecret(spec).getEncoded();
        return String.format("%d:%s:%s", ITERATIONS,
            Base64.getEncoder().encodeToString(salt),
            Base64.getEncoder().encodeToString(out));
    }
}