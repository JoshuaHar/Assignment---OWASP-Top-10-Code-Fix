const mongoSanitize = require('mongo-sanitize');

app.get('/user', async (req, res) => {
  try {
    const raw = req.query.username;
    // Validate type & length
    if (!raw || typeof raw !== 'string' || raw.length > 100) {
      return res.status(400).json({ error: 'Invalid username' });
    }
    const username = mongoSanitize(raw);
    const user = await db.collection('users').findOne(
      { username: username },
      { projection: { passwordHash: 0 } }
    );
    if (!user) return res.status(404).json({ error: 'Not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});