import secrets, hashlib
from datetime import datetime, timedelta
from flask import url_for

@app.route('/request-reset', methods=['POST'])
def request_reset():
    email = request.form.get('email')
    user = User.query.filter_by(email=email).first()
    if user:
        token = secrets.token_urlsafe(48)
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        user.reset_token_hash = token_hash
        user.reset_token_expires = datetime.utcnow() + timedelta(hours=1)
        db.session.commit()
        reset_link = url_for('perform_reset', token=token, _external=True)
        send_email(user.email, f"Reset link: {reset_link}")
    return 'If your email exists, you will receive a reset link', 200

@app.route('/perform-reset/<token>', methods=['POST'])
def perform_reset(token):
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    user = User.query.filter_by(reset_token_hash=token_hash).first()
    if not user or user.reset_token_expires < datetime.utcnow():
        return 'Invalid or expired token', 400
    new_password = request.form.get('new_password')
    user.password_hash = hash_password(new_password)
    user.reset_token_hash = None
    user.reset_token_expires = None
    db.session.commit()
    return 'Password updated', 200
