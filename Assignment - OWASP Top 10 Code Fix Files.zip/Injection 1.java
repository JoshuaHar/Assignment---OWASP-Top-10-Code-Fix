String username = request.getParameter("username");
String query = "SELECT id, username, email FROM users WHERE username = ?";
PreparedStatement ps = connection.prepareStatement(query);
ps.setString(1, username);
ResultSet rs = ps.executeQuery();