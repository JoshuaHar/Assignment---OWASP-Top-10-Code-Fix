import org.mindrot.jbcrypt.BCrypt;

String hashed = BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));

boolean ok = BCrypt.checkpw(inputPassword, storedHash);
if (ok) {
}