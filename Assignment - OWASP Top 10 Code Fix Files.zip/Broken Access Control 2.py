from flask_login import login_required, current_user
from flask import abort, jsonify

@app.route('/account/<user_id>')
@login_required
def get_account(user_id):
    if str(current_user.id) != str(user_id) and not getattr(current_user, 'is_admin', False):
        abort(403)
    user = db.query(User).filter_by(id=user_id).first_or_404()
    return jsonify(user.to_public_dict())