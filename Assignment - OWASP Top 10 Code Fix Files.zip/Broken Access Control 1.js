app.get('/profile/:userId', authenticate, async (req, res) => {
  const requestedId = req.params.userId;
  const currentUser = req.user;

  if (currentUser.id !== requestedId && !currentUser.roles?.includes('admin')) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  try {
    const user = await User.findById(requestedId).select('-password -ssn');
    if (!user) return res.status(404).send({ error: 'Not found' });
    res.json(user);
  } catch (err) {
    res.status(500).send({ error: 'Server error' });
  }
});