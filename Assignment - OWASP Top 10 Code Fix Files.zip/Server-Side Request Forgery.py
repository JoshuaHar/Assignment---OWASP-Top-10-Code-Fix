import requests
from urllib.parse import urlparse
import socket, ipaddress

ALLOWED_HOSTS = {'api.example.com', 'data.example.com'}

def is_private_address(hostname):
    try:
        infos = socket.getaddrinfo(hostname, None)
    except Exception:
        return True
    for entry in infos:
        ip_str = entry[4][0]
        ip = ipaddress.ip_address(ip_str)
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return True
    return False

def safe_fetch(url):
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https'):
        raise ValueError('Only http(s) allowed')
    hostname = parsed.hostname
    if hostname not in ALLOWED_HOSTS:
        raise ValueError('Hostname not allowed')
    if is_private_address(hostname):
        raise ValueError('Resolved address is private or loopback')
    resp = requests.get(url, timeout=5)
    return resp.text

# Example:
try:
    print(safe_fetch("https://api.example.com/data"))
except Exception as e:
    print("Error:", e)